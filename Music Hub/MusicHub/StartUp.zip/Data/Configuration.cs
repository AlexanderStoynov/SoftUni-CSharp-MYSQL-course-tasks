﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            "Server=localhost;Database=MusicHub;Integrated Security=true;Trust Server Certificate = true";
    }
}
